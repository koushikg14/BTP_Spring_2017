# UWaterloo-Tunnel-Route-Widget
A widget that suggests, between any two campus buildings, the shortest indoor route, or rather the route which minimizes the exposure to sun.
Also has the option to simply show the outside route or the option to choose "weather-dependent" which checks the weather and suggests which route to take between indoor and outdoor.
